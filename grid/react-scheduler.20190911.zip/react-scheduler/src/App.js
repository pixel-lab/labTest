import React, {Component} from 'react';
import './App.css';
import Scheduler from "./scheduler/Scheduler";

class App extends Component {
  render() {
    return (
        <Scheduler/>
    );
  }
}

export default App;
