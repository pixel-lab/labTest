# DayPilot Scheduler React Tutorial

[Read more](./readme/readme.html)

This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).
