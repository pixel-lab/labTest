import React from 'react'

const CreateClassHeading = React.createClass({
  render: function() {
    return (
      <h1>Hello</h1>
    )
  }
});

export default CreateClassHeading
