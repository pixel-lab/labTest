import React from 'react'

class Heading extends React.Component {
  render() {
    return (
      <h1>Hello</h1>
    )
  }
};

export default Heading
