import WouldYouRather from './app'
import { AppRegistry } from 'react-native'

AppRegistry.registerComponent('WouldYouRather', () => WouldYouRather)
